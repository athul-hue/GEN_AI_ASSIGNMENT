ASSIGNMENT 5 - STYLEGAN2 LATENT SPACE

Files:
1. Assignment_5_StyleGAN2_Latent_Space.ipynb

How to use:
1. Open the .ipynb file in Google Colab.
2. Select Runtime -> Change runtime type -> GPU (recommended).
3. Run all cells from top to bottom.
4. The notebook downloads a pretrained StyleGAN2-ADA FFHQ model automatically.
5. It generates two initial images, 12 interpolation frames, an image strip, a GIF, and a one-dimension experiment.
6. Download the generated files from /content for submission.

Required submission:
- Two initial generated images
- Interpolation images
- GIF or image strip
- Short written observation

The notebook already contains the observation text and code needed for the assignment.
